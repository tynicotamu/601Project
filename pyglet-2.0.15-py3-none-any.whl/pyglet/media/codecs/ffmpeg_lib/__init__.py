"""FFmpeg wrapping"""
from .libavcodec import *
from .libavutil import *
from .libavformat import *
from .libswresample import *
from .libswscale import *
from .compat import *
apply_version_changes()
